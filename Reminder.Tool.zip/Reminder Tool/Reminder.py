import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json
import os
import threading
import time



class UltraFloatingReminder:

    def get_settings_path(self):
      return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ultra_floating_reminder_settings.json')


    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Ultra Floating Reminder")

        
        self.is_movable_mode = False
        self.click_count = 0
        self.last_click_time = 0
        self.triple_click_window = 600 

        self.root.wm_attributes('-topmost', True)  
        self.root.wm_attributes('-disabled', False)
        self.root.wm_attributes('-toolwindow', True)

        self.root.lift()
        self.root.focus_force()

        self.root.overrideredirect(True)
        self.root.attributes('-alpha', 1.0)
        self.root.configure(bg='black')
        self.root.wm_attributes('-transparentcolor', 'black')

        self.settings = {
            'text': 'ALERT', 'x': 1195, 'y': 10,
            'color': 'yellow', 'size': 16, 'font': 'Arial Black'
        }

        self.keyboard_move_step = 10  
        self.drag_data = {}

        self.load_settings()

        self.label = tk.Label(
            self.root,
            text=self.settings['text'],
            font=(self.settings['font'], self.settings['size'], 'bold'),
            fg=self.settings['color'],
            bg='black', padx=5, pady=5, borderwidth=2,
            relief='solid', highlightthickness=0, compound='center'
        )
        self.label.pack()

        self.root.geometry(f"+{self.settings['x']}+{self.settings['y']}")

        
        self.label.bind('<Button-1>', self.handle_mouse_press)
        self.label.bind('<B1-Motion>', self.drag)  
        self.label.bind('<ButtonRelease-1>', self.handle_mouse_release)

        
        self.root.bind('<Up>', self.move_with_keyboard)
        self.root.bind('<Down>', self.move_with_keyboard)
        self.root.bind('<Left>', self.move_with_keyboard)
        self.root.bind('<Right>', self.move_with_keyboard)

        self.label.bind('<Button-3>', self.show_menu)      
        

        self.create_menu()
        self.root.after(1000, self.auto_save)

        self.keep_running = True
        self.force_thread = threading.Thread(
            target=self.force_on_top_forever, daemon=True)
        self.force_thread.start()

        self.root.protocol("WM_DELETE_WINDOW", self.prevent_close)
        self.root.bind('<FocusOut>', self.force_focus_back)
        self.root.after(100, self.anti_hide_check)

        self.root.focus_set()

    def handle_mouse_press(self, event):
        current_time = time.time() * 1000  # milliseconds

        if current_time - self.last_click_time < self.triple_click_window:
            self.click_count += 1
        else:  
            self.click_count = 1

        self.last_click_time = current_time

        if self.click_count == 3:
            print("Triple-click detected: Entering movable mode.")
            self.is_movable_mode = True
            self.root.wm_attributes('-topmost', False)
            self.click_count = 0  
            self.start_drag(event)  
        elif self.click_count == 2 and (current_time - self.last_click_time) < (self.triple_click_window / 1.5):
            # If it was a quick double click, allow text editing
            # Check time between last two clicks is small for double click
            # This check is a bit heuristic. We need to distinguish double from start of triple.
            # Let's assume a double click is faster than the full triple_click_window.
            # For simplicity, we can also just remove double-click edit if it conflicts.
            # For now, let's prioritize triple-click. Editing via menu is still an option.
            # self.edit_text() # Potentially re-enable if desired, or remove this else-if
            pass

    def start_drag(self, event):
        """Records initial mouse offset IF in movable_mode."""
        if self.is_movable_mode:
            self.drag_data['offset_x'] = event.x_root - self.root.winfo_x()
            self.drag_data['offset_y'] = event.y_root - self.root.winfo_y()
            print("Drag started in movable mode.")

    def drag(self, event):
        """Moves window if in movable_mode."""
        if self.is_movable_mode and 'offset_x' in self.drag_data:
            new_x = event.x_root - self.drag_data['offset_x']
            new_y = event.y_root - self.drag_data['offset_y']
            self.root.geometry(f"+{new_x}+{new_y}")
            

    def handle_mouse_release(self, event):
        """Ends drag and reverts to normal state if in movable_mode."""
        if self.is_movable_mode:
            print("Mouse released: Exiting movable mode.")
            self.is_movable_mode = False  

            if 'offset_x' in self.drag_data:  
                self.settings['x'] = self.root.winfo_x()
                self.settings['y'] = self.root.winfo_y()
                self.save_settings()

            self.drag_data = {}  
            self.click_count = 0  

            self._ensure_on_top() 
            self.root.focus_set()
      

    def move_with_keyboard(self, event): 
        current_x = self.root.winfo_x()
        current_y = self.root.winfo_y()
        step = self.keyboard_move_step

        if event.keysym == 'Up':
            current_y -= step
        elif event.keysym == 'Down':
            current_y += step
        elif event.keysym == 'Left':
            current_x -= step
        elif event.keysym == 'Right':
            current_x += step

        self.root.geometry(f"+{current_x}+{current_y}")
        self.settings['x'] = current_x
        self.settings['y'] = current_y
        if not self.is_movable_mode:  
            self._ensure_on_top()

    def force_on_top_forever(self):
        while self.keep_running:
            try:
                if self.root and self.root.winfo_exists():
                    if not self.is_movable_mode: 
                        self.root.lift()
                        self.root.wm_attributes('-topmost', True)
                        if self.root.state() != 'normal':
                            self.root.deiconify()
                            self.root.state('normal')
                        if not self.root.winfo_viewable():
                            self.root.deiconify()
                else:
                    break
                time.sleep(0.1)
            except tk.TclError:
                break
            except Exception:
                break

    def anti_hide_check(self):
        try:
            if self.root and self.root.winfo_exists():
                if not self.is_movable_mode: 
                    if not self.root.winfo_viewable() or self.root.state() != 'normal':
                        self.root.deiconify()
                        self.root.state('normal')
                    self.root.lift()
                    self.root.wm_attributes('-topmost', True)

                if self.keep_running:
                    self.root.after(50, self.anti_hide_check)
            else:
                return
        except tk.TclError:
            pass
        except Exception:
            pass

    def force_focus_back(self, event=None):
        try:
            if self.root and self.root.winfo_exists() and self.keep_running:
                if not self.is_movable_mode: 
                    self.root.lift()
                    self.root.wm_attributes('-topmost', True)
        except tk.TclError:
            pass
        except Exception:
            pass

    def prevent_close(self):
        temp_parent = tk.Toplevel(self.root)
        temp_parent.attributes('-topmost', True)
        temp_parent.withdraw()
        messagebox.showwarning("Action Blocked",
                               "This reminder cannot be closed this way.\n"
                               "Right-click for options and use 'FORCE EXIT'.",
                               parent=temp_parent)
        if temp_parent.winfo_exists():
            temp_parent.destroy()

        if not self.is_movable_mode:
            self._ensure_on_top()
        self.root.focus_set()

    def create_menu(self):
        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="✏️ Edit Text",
                              command=self.edit_text)  
        self.menu.add_separator()
        self.menu.add_command(label="🎨 Change Color",
                              command=self.change_color)
        self.menu.add_command(label="📏 Change Size", command=self.change_size)
        self.menu.add_separator()
        self.menu.add_command(label="🔄 Reset Position",
                              command=self.reset_position_to_initial_defaults)
        self.menu.add_separator()
        self.menu.add_command(label="❌ FORCE EXIT", command=self.force_exit)

    def show_menu(self, event):
        was_movable = self.is_movable_mode
        self.is_movable_mode = True 
        self.root.wm_attributes('-topmost', False)
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()
            self.is_movable_mode = was_movable  
            if not self.is_movable_mode:
                self.root.after(10, lambda: (
                    self._ensure_on_top(), self.root.focus_set()))
            else: 
                self.root.wm_attributes('-topmost', False)
                self.root.focus_set()

    def _ensure_on_top(self):  
        try:
            if self.root and self.root.winfo_exists():
                self.root.lift()
                self.root.wm_attributes('-topmost', True)
        except tk.TclError:
            pass

    def _create_temporary_topmost_parent(self):
        temp_parent = tk.Toplevel(self.root)
        temp_parent.transient(self.root)
        main_was_topmost_strict = False
        if not self.is_movable_mode and self.root.wm_attributes('-topmost'):
            main_was_topmost_strict = True
            

        
        temp_parent.attributes('-topmost', True)
        temp_parent.withdraw() 

        
        def restore_main():
            if main_was_topmost_strict:
                self._ensure_on_top()  
            if not self.is_movable_mode:
                self._ensure_on_top()

        return temp_parent, restore_main

    def edit_text(self, event=None):
        if self.is_movable_mode and 'offset_x' in self.drag_data:
            return

        temp_parent, restore_main_topmost = self._create_temporary_topmost_parent()
        new_text = simpledialog.askstring("Edit Text", "Enter text:",
                                          initialvalue=self.settings['text'],
                                          parent=temp_parent)
        if temp_parent.winfo_exists():
            temp_parent.destroy()
        restore_main_topmost()

        if new_text is not None:
            self.settings['text'] = new_text
            self.label.config(text=new_text)
            self.save_settings()

        if not self.is_movable_mode:
            self._ensure_on_top()
        self.root.focus_set()

    def _custom_dialog_setup(self, title, setup_content_callback):
        main_needs_restore = False
        if not self.is_movable_mode and self.root.wm_attributes('-topmost'):
            
            main_needs_restore = True

        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.transient(self.root)
        dialog.attributes('-topmost', True)  
        dialog_x = self.root.winfo_x() + 30
        dialog_y = self.root.winfo_y() + 30
        dialog.geometry(f"+{dialog_x}+{dialog_y}")

        setup_content_callback(dialog)  

        dialog.grab_set()  

        def on_close():
            if dialog.winfo_exists():
                dialog.grab_release()
                dialog.destroy()
            if main_needs_restore and not self.is_movable_mode:
                self._ensure_on_top()
            self.root.focus_set()

        dialog.protocol("WM_DELETE_WINDOW", on_close)
        return dialog, on_close 

    def change_color(self):
        if self.is_movable_mode and 'offset_x' in self.drag_data:
            return

        def setup_color_buttons(dialog_instance):
            colors = ['white', 'red', 'blue', 'green', 'purple',
                      'orange', 'yellow', 'cyan', 'magenta', 'black']
            dialog_instance.geometry("200x350")
            for color_name in colors:
                text_fg = 'black' if color_name in [
                    'white', 'yellow', 'cyan'] else 'white'
                if color_name == 'black':
                    text_fg = 'white'
                btn = tk.Button(dialog_instance, text=color_name.title(), bg=color_name, fg=text_fg,
                                command=lambda c=color_name, d=dialog_instance: self._set_color_and_close_custom(c, d))
                btn.pack(fill='x', padx=10, pady=3)

        self._custom_dialog_setup("Choose Color", setup_color_buttons)

    def _set_color_and_close_custom(self, color, dialog_window):
        self.settings['color'] = color
        self.label.config(fg=color)
        self.save_settings()

        
        if dialog_window and dialog_window.winfo_exists():
            dialog_window.grab_release()
            dialog_window.destroy()

        if not self.is_movable_mode:  
            self._ensure_on_top()
        self.root.focus_set()

    def change_size(self):
        if self.is_movable_mode and 'offset_x' in self.drag_data:
            return

        temp_parent, restore_main_topmost = self._create_temporary_topmost_parent()
        new_size = simpledialog.askinteger("Change Size", "Enter font size (8-72):",
                                           initialvalue=self.settings['size'],
                                           minvalue=8, maxvalue=72, parent=temp_parent)
        if temp_parent.winfo_exists():
            temp_parent.destroy()
        restore_main_topmost()

        if new_size is not None:
            self.settings['size'] = new_size
            self.label.config(font=(self.settings['font'], new_size, 'bold'))
            self.save_settings()

        if not self.is_movable_mode:
            self._ensure_on_top()
        self.root.focus_set()

    def reset_position_to_initial_defaults(self):
        if self.is_movable_mode and 'offset_x' in self.drag_data:
            return
        initial_defaults = {
            'text': 'ALERT', 'x': 1195, 'y': 10,
            'color': 'yellow', 'size': 16, 'font': 'Arial Black'
        }
        self.settings.update(initial_defaults)
        self.label.config(text=self.settings['text'], fg=self.settings['color'],
                          font=(self.settings['font'], self.settings['size'], 'bold'))
        self.root.geometry(f"+{self.settings['x']}+{self.settings['y']}")
        self.save_settings()
        if not self.is_movable_mode:
            self._ensure_on_top()
        self.root.focus_set()

    def force_exit(self):
        temp_parent, restore_main_topmost = self._create_temporary_topmost_parent()
        result = messagebox.askyesno(
            "FORCE EXIT", "Are you SURE you want to exit?", parent=temp_parent)
        if temp_parent.winfo_exists():
            temp_parent.destroy()
        

        if result:
            self.keep_running = False
            if self.force_thread.is_alive():
                self.force_thread.join(timeout=0.2)
            self.save_settings()
            if self.root and self.root.winfo_exists():
                self.root.destroy()

    def load_settings(self):
        settings_file = self.get_settings_path()

        if os.path.exists(settings_file):
            try:
                with open(settings_file, 'r') as f:
                    saved_settings = json.load(f)
                if isinstance(saved_settings, dict):
                    for key in self.settings:
                        if key in saved_settings:
                            self.settings[key] = saved_settings[key]
            except Exception:
                print(f"Error loading {settings_file}. Using defaults.")
        try:  # Ensure types
            self.settings['x'] = int(self.settings.get('x', 1195))
            self.settings['y'] = int(self.settings.get('y', 10))
            self.settings['size'] = int(self.settings.get('size', 16))
        except ValueError:
            self.settings.update({'x': 1195, 'y': 10, 'size': 16})

    def save_settings(self):
        current_config = {
            'text': self.settings.get('text'), 'x': self.root.winfo_x(),
            'y': self.root.winfo_y(), 'color': self.settings.get('color'),
            'size': self.settings.get('size'), 'font': self.settings.get('font')
        }
        try:
            settings_file = self.get_settings_path()
            with open(settings_file, 'w') as f:

                json.dump(current_config, f, indent=4)
        except Exception as e:
            print(f"Error saving settings: {e}")

    def auto_save(self):
        if not self.keep_running:
            return
        if self.root and self.root.winfo_exists():
            if not self.is_movable_mode:  
                self.save_settings()
            if not self.is_movable_mode:
                self._ensure_on_top()
            self.root.after(30000, self.auto_save)

    def run(self):
        try:
            if not self.is_movable_mode:
                self._ensure_on_top()
            self.root.focus_set()
            print(
                "ULTRA FLOATING REMINDER: Triple-click text to move. Release mouse to fix.")
            print(f"Initial: x={self.settings['x']}, y={self.settings['y']}")
            self.root.mainloop()
        except KeyboardInterrupt:
            self.force_exit()
        finally:
            self.keep_running = False
            print("Ultra Floating Reminder exited.")


if __name__ == "__main__":
    app = UltraFloatingReminder()
    app.run()